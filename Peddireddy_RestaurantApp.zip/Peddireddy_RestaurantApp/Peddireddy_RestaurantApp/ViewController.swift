//
//  RestaurantHomeVC.swift
//  Peddireddy_RestaurantApp
//
//  Created by student on 4/26/22.
//

import UIKit

class ViewController: UITableViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem
    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        restaurentname.count
    }
    
    let restaurentname = restaurants

    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        let restorentList = self.restaurentname[indexPath.row]
        if let Cell = cell as? RestaurantsTVC{
            Cell.restNameLBL.text = restorentList.name
        }

        return cell
    }
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        self.performSegue(withIdentifier: "menuSegu", sender: indexPath)
    }
    

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if let identifier = segue.identifier{
            switch identifier{
            case "menuSegu":
                if let destinationVC = segue.destination as? RestaurantDetailsViewController {
                    if let ip = sender as? IndexPath{
                        destinationVC.restmenu = self.restaurentname[ip.row].details!
                    }
                }
            default: break
            }
        }
    }
    

}
