//
//  RestaurantsTVC.swift
//  Peddireddy_RestaurantApp
//
//  Created by student on 4/26/22.
//

import UIKit

class RestaurantsTVC: UITableViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    @IBOutlet weak var restNameLBL: UILabel!
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
