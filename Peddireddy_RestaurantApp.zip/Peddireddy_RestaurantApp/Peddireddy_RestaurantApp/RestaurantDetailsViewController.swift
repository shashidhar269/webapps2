//
//  menuVC.swift
//  Peddireddy_RestaurantApp
//
//  Created by student on 4/26/22.
//

import UIKit

class RestaurantDetailsViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        self.restaurentimg.image = UIImage(named: restmenu.image!)
        self.item1LBL.text = ""
        self.item2LBL.text = ""
        self.item3LBL.text = ""
        self.item4LBL.text = ""
        self.item5LBL.text = ""
        // Do any additional setup after loading the view.
    }
    
    @IBAction func menuBTN(_ sender: UIButton) {
        self.item1LBL.text = restmenu.item1
        self.item2LBL.text = restmenu.item2
        self.item3LBL.text = restmenu.item3
        self.item4LBL.text = restmenu.item4
        self.item5LBL.text = restmenu.item5
    }
    @IBOutlet weak var restaurentimg: UIImageView!
    
    @IBOutlet weak var item1LBL: UILabel!
    
    @IBOutlet weak var item2LBL: UILabel!
    
    @IBOutlet weak var item3LBL: UILabel!
    
    @IBOutlet weak var item4LBL: UILabel!
    
    @IBOutlet weak var item5LBL: UILabel!
    
    
    var restmenu = RestDetails()

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
